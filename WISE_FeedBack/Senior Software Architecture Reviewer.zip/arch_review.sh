#!/bin/bash
# A simple script to find architecture violations
echo "=== 1. Use of Infrastructure/EF in Application/Api Layer ==="
grep -r "using Microsoft.EntityFrameworkCore" src/WISE.Application/ || echo "No EF in Application"
grep -r "using Microsoft.EntityFrameworkCore" src/WISE.Domain/ || echo "No EF in Domain"
grep -r "WiseDbContext" src/WISE.Api/Controllers/ | grep -v "//" || echo "No DbContext in Controllers"
grep -r "WiseDbContext" src/WISE.Api/UseCases/ | grep -v "//" || echo "No DbContext in UseCases"
grep -r "WiseDbContext" src/WISE.Application/ || echo "No DbContext in Application"

echo -e "\n=== 2. UseCases inside Api ==="
ls -la src/WISE.Api/UseCases/

echo -e "\n=== 3. Domain dependencies on outer layers ==="
grep -r "WISE.Application" src/WISE.Domain/ || echo "No Domain -> Application"
grep -r "WISE.Infrastructure" src/WISE.Domain/ || echo "No Domain -> Infrastructure"
grep -r "using Microsoft.Extensions." src/WISE.Domain/ || echo "No extensions in Domain"

echo -e "\n=== 4. Controllers directly returning Entities ==="
grep -r "public Task<ActionResult<Work>>" src/WISE.Api/Controllers/ || echo "No Works returned directly"

