# WISE Architecture Review

## Overview
This is an architectural review of the WISE project, evaluated against Domain-Driven Design (DDD), Clean Architecture, SOLID principles, and generic dependency rules.

## Clean Architecture & Dependency Rule
The project structure nominally follows Clean Architecture layers:
- `WISE.Domain` (Core entities, interfaces, enums, value objects)
- `WISE.Application` (Use cases, application services, DTOs)
- `WISE.Infrastructure` (Data access, EF Core, providers)
- `WISE.Api` (Presentation / API)
- `WISE.Plugin` (Extension points)

### Violations
**CRITICAL: `WISE.Api` contains UseCases and directly uses `WiseDbContext`**
- `WISE.Api/UseCases/FetchMetadataJobUseCase.cs`
- `WISE.Api/UseCases/CreateImportJobUseCase.cs`
- `WISE.Api/UseCases/ExecuteImportJobUseCase.cs`
- `WISE.Api/UseCases/ImportUseCase.cs`
These UseCases reside in the presentation layer (`WISE.Api`) rather than the `WISE.Application` layer where they belong. Furthermore, they directly inject and depend on `WiseDbContext` (an EF Core infrastructure concern).

**CRITICAL: Infrastructure leaking into Presentation (`WISE.Api`)**
Almost every controller directly injects `WiseDbContext` instead of relying on domain repositories or application services:
- `HomeController`, `CollectionsController`, `HistoryController`, `WorksController`, `AssetsController`, `JobsController`, `DuplicatesController`, `WatchFoldersController`, `SystemController`, `ReaderController`, `SettingsController`.
This completely bypasses the Application layer and tightly couples the API to Entity Framework Core.

## Domain-Driven Design (DDD)
- **Domain Layer:** The domain layer (`WISE.Domain`) correctly avoids infrastructure dependencies. It defines Aggregate Roots (e.g., `Work`), Entities, and Interfaces. It doesn't reference `Microsoft.EntityFrameworkCore`.
- **Anemic Domain vs Rich Domain:** `Work.cs` appears to have some logic (e.g., encapsulating lists with `AsReadOnly()`) which is good.

## SOLID Principles
- **Dependency Inversion Principle (DIP):** Violated heavily in `WISE.Api`. Controllers and UseCases depend directly on a concrete SQL-based context (`WiseDbContext`) rather than abstract interfaces (e.g., `IWorkRepository`).
- **Single Responsibility Principle (SRP):** Controllers directly querying EF Core means they handle both HTTP request mapping and data access logic, violating SRP. `FetchMetadataJobUseCase` taking `WiseDbContext` along with `IWorkRepository` indicates mixed responsibilities.

## Repositories, Services, UseCases
- **Repositories:** Defined in `WISE.Domain.Interfaces` and implemented in `WISE.Infrastructure.Data.Repositories` (Good). However, they are bypassed by the API layer (Bad).
- **UseCases:** Found in both `WISE.Application/UseCases` (e.g., `ProcessNewAssetUseCase`) and `WISE.Api/UseCases`. The latter is an architectural anomaly.

## Extension Points & Plugin Readiness
The presence of `WISE.Plugin` suggests an intention for extensibility. Interfaces like `IMetadataProvider`, `IArchiveReaderFactory`, and `IArchiveReader` show good plugin readiness. However, if plugins need database access, the leaky `WiseDbContext` might set a bad precedent for plugin developers.

## Summary
- **Architecture violations:** Controllers and API UseCases bypassing application/domain layers to query EF Core directly. UseCases living in the API project.
- **Coupling:** High coupling between Presentation (API) and Infrastructure (EF Core).
- **Future risks:** Changing the database provider or data access strategy will require rewriting the entire API layer. Testing is hindered because mocking a DbContext is much harder than mocking an application service or repository.
- **Suggested refactoring:**
  1. Move all UseCases from `WISE.Api/UseCases/` to `WISE.Application/UseCases/`.
  2. Refactor all UseCases and Controllers to use abstract repositories (e.g., `IWorkRepository`) instead of `WiseDbContext`.
  3. Ensure `WISE.Api` does not reference `WISE.Infrastructure` directly except for dependency injection configuration in `Program.cs`.
- **Maintainability score:** 5/10. The domain logic is clean, but the application/infrastructure coupling in the API layer severely diminishes maintainability.
