using System;
using System.IO;

string path = "/tmp/testdir";
try {
    var files = Directory.GetFiles(path, "*.*", SearchOption.AllDirectories);
    Console.WriteLine("Success: " + files.Length);
} catch (Exception ex) {
    Console.WriteLine("Error: " + ex.Message);
}
