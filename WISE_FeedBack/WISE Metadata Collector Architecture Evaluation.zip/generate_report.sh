#!/bin/bash
cat << 'REPORT' > SCRAPING_ARCH_REPORT.md
# WISE Metadata Scraper Architecture Review

## 1. Provider Architecture
WISE implements a strategy pattern for metadata providers through the `IMetadataProvider` interface. The `MetadataService` fetches candidates from applicable providers based on `SupportedMediaTypes` and uses a `MetadataConflictResolver` to elect primary values based on confidence, priority, and manual overrides.
- **Strength:** Excellent modularity and open/closed principle adherence. Allows easy addition of new providers (e.g., ComicInfoXml, Dlsite, FanzaDoujin).
- **Weakness:** The current strategy of fetching all applicable providers in parallel can lead to redundant network requests if a high-priority provider (like Fanza) succeeds. A sequential fallback or cancellation token mechanism could save resources and prevent rate-limits from lower priority providers (like AvWiki).

## 2. Retry Policy
The `IRetryPolicy` interface exists, but it's not actually implemented or used in any of the existing metadata providers.
- **Weakness:** Lack of implemented retry policies makes the system vulnerable to transient network errors or temporary rate limits. Polly or similar resilience frameworks should be integrated.

## 3. Cookie Handling
Cookies are managed well through the `ICookieProvider` and `ICookiePolicy` interfaces. The system supports loading from Playwright `storageState.json` (Playwright / Cookie Editor export) and fallback `.txt` files.
- **Strength:** Clean separation of concerns. Easy for users to provide cookies.
- **Weakness:** Relies heavily on the user or an external process to maintain active sessions.

## 4. Rate Limiting
`FailureReason.RateLimit` exists in the domain, and providers like DLSite, Getchu, and JavBus check for 429 status codes. However, there is no global rate limiter or polite delay between requests across the application.
- **Weakness:** Rapidly processing jobs could easily trigger bans on providers. A global rate limiter (e.g., `System.Threading.RateLimiting`) per domain is highly recommended.

## 5. HTTP Client
Providers are injected with `HttpClient` via their constructors.
- **Weakness:** They seem to depend on transient or singleton `HttpClient` instances directly instead of using `IHttpClientFactory`. This can lead to socket exhaustion or stale DNS issues. Some providers also manually set `Accept-Encoding` which disables the built-in auto-decompression.

## 6. Browser Automation
The `FanzaMetadataProvider` employs a hybrid approach, using Playwright (Chromium) as the primary strategy to handle JS-rendered content and Cloudflare, falling back to `HtmlAgilityPack` if it fails.
- **Strength:** Playwright integration is robust for difficult sites.
- **Weakness:** Playwright is heavy. Creating a new browser context for every request might be slow. A pool of contexts or pages could improve performance.

## 7. Cloudflare Strategy
JavBus checks for Cloudflare (`cf-browser-verification`) and returns a specific failure. Mgs checks for age verification and mentions `FutureStrategy=Browser`.
- **Weakness:** Currently, only Fanza actively uses Playwright. Other providers just fail when encountering Cloudflare. The Playwright infrastructure should be abstracted and made available to all providers (like JavBus) that need to bypass Cloudflare.

## 8. Age Verification
Age verification is handled primarily by injecting cookies (Fanza, FC2). If the cookie is missing or expired, providers detect the age verification page (e.g., Mgs, Fanza Doujin) and return `FailureReason.AgeVerification`.
- **Strength:** Properly detects the gate instead of parsing it as a normal page.
- **Weakness:** Manual cookie refresh required by the user.

## 9. Session Persistence
Session persistence relies on the user exporting Playwright storage states to `%APPDATA%\WISE\`.
- **Strength:** Simple and avoids storing credentials.
- **Weakness:** User experience requires manual intervention when sessions expire.

## 10. Provider Priority
Priority is well-defined and configurable via `MetadataProviderOptions`.
Default priorities for Video: `Manual (100) > Fanza (80) > JavBus (70) = Mgs (70) = FC2 (70) > AvWiki (60) > Fc2Alt (55) > DoujinishiFilename (50) > LocalNFO (40)`.
- **Recommendation:** This ordering is generally sound.

## 11. Cache
The system has a robust `CoverCacheRepository` to avoid re-downloading images. It uses `ICoverProvider` strategies (Metadata, Archive, VideoThumbnail, Epub) to extract and cache covers.
- **Strength:** Good caching for heavy assets.
- **Weakness:** HTTP response caching for metadata (e.g., HTML pages or API JSON) doesn't appear to be implemented, meaning re-scraping is expensive.

## 12. Diagnostics
`ProviderDiagnostic` tracks success/failure counts, average latency, and reasons.
- **Strength:** Excellent observability into scraper health and performance.

## Suggested Best Provider Order

### Video Providers
1. `Fanza` (80) - Best quality for commercial AV.
2. `Mgs` (70) - Good fallback for commercial.
3. `FC2` (65) - For FC2-PPV content.
4. `JavBus` (60) - Excellent fallback for commercial (needs Cloudflare bypass implemented).
5. `AvWiki` (55) - Good for actress data and filling gaps.
6. `Fc2Alt` (50) - Scrapes third-party tubes; lowest quality metadata.

### Comic / Doujin Providers
1. `DLSite` (80) - Authoritative for doujinshi and audio.
2. `Fanza Doujin` (80) - Authoritative for DMM doujin.
3. `Getchu` (70) - Good for PC games / commercial doujin.
4. `ComicInfoXml` (90) - Should be high priority if local metadata exists.
5. `LocalNFO` (40) - Local overrides.

## Coverage Evaluation

- **FANZA:** Covered well, utilizing Playwright for SPA/JS handling. High quality.
- **FC2:** Covered, but fragile due to seller deletions and strict age gates. Relies on cookies.
- **DLSite:** Implemented and handles RJ/VJ/BJ prefixes well. High quality metadata.
- **Getchu:** Implemented.
- **MGS:** Implemented. Good fallback for Fanza.
- **Official maker sites:** Not explicitly covered. Relies on Fanza/Mgs/JavBus.
- **JAVLibrary:** Not implemented. Could be a good addition alongside JavBus.
- **JAVBus:** Implemented, but currently fails on Cloudflare protection. Needs Playwright integration.
- **Wikis:** `AvWiki` is implemented as a low-priority fallback. Excellent for actress names and tags.

## Conclusion
WISE has a very solid foundation for metadata collection. The Strategy pattern, Priority system, and Conflict Resolver are excellent architectural choices. To become the "world's best", it needs to address:
1. **Resilience:** Implement `IRetryPolicy` and global rate limiting to avoid bans.
2. **Abstract Browser Automation:** Move Playwright out of `FanzaMetadataProvider` into a shared service so `JavBus` and others can bypass Cloudflare.
3. **HTTP Client:** Refactor to use `IHttpClientFactory`.
4. **Caching:** Implement HTTP response caching for metadata requests.
REPORT
